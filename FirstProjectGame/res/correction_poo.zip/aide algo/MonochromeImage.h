#include <iostream>

using namespace std;


class MonochromeImage {
private:

    int** tableauPixel;

    int hauteur, largeur;


public:

    MonochromeImage(int largeur, int hauteur);
    ~MonochromeImage();


    int getCase(int x, int y);

    void afficher();
};