#include "MonochromeImage.h"


int main() {

    // "instanciation" de la class
    // on créer un objet image et on appelle le constructeur
    MonochromeImage* image = new MonochromeImage(10, 15);

    // maintenant que l'objet existe, on appelle ses méthodes pour voir si elles fonctionnent
    image->afficher();

    cout << image->getCase(0,0) << "   " <<  image->getCase(0,5) << "\n normalement ca vaut 0" << endl;


    // on a finis, donc on delete l'objet (un new = un delete) 
    // ça permet d'éviter les fuites mémoires (et de perdres des points bêtes aux ds)
    delete image;

    return 0;
}