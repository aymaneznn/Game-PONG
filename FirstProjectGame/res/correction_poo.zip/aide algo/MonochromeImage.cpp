#include "MonochromeImage.h"

MonochromeImage::MonochromeImage(int largeur, int hauteur) {
    // le constructeur est appelé est créé les différents éléments de la classe

    this->hauteur = hauteur;
    this->largeur = largeur;

    // première allocation du tableau de int
    tableauPixel = new int*[hauteur];

    // allocation de tout le tableau
    for(int i = 0; i < hauteur; i++) {

        // on créé les cases en largeur
        int* t = new int[largeur];
        // et on les ajoute aux tableaux
        tableauPixel[i] = t;
        
        // on remplit ensuite les valeurs créé par un 0 qui servent de valeurs initial
        for(int k = 0; k < largeur; k++) {
            tableauPixel[i][k] = 0;
        }
    }

    // le tableau est prêt à l'emploie
}

MonochromeImage::~MonochromeImage() {
     for(int i = 0; i < hauteur; i++) {
        delete []tableauPixel[i];
    }

    delete []tableauPixel;
}


int MonochromeImage::getCase(int x, int y) {

    if(x >= 0 && x < hauteur  &&  y >= 0 && y < largeur) {
        return tableauPixel[x][y];
    }

    return -1; // le tableau ne pouvant pas contenir -1 (que des valeurs positives) le -1 peut te servir de message d'erreur
}

void MonochromeImage::afficher() {
    for(int i = 0; i < hauteur; i++) {
        cout << "\t |";
        for(int k = 0; k < largeur; k++) {
            cout << " " << tableauPixel[i][k];

        }
        cout << " |" << endl;
    }

}